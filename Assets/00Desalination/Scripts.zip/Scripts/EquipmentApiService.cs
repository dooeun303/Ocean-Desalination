using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
///
/// <summary>
/// Express ������ GET /api/equipment/:id �� ȣ���Ͽ�
/// equipment �����͸� �������� ����
///
/// [����]
/// EquipmentApiService.Instance.GetEquipmentById(
///     equipmentId,
///     onSuccess: (data) => { ... },
///     onError:   (msg)  => { ... }
/// );
/// </summary>
/// 
public class EquipmentApiService : MonoBehaviour
{

    public static EquipmentApiService Instance { get; private set; }

    [Header("��������")]
    [SerializeField] private string baseUrl = "http://localhost:3000";
    [SerializeField] private float timeoutSeconds = 10f;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void GetEquipmentById(int equipmentId, Action<EquipmentData> onSuccess, Action<string> onError)
    {
        StartCoroutine(FetchEquipment(equipmentId, onSuccess, onError));
        
    }

    private IEnumerator FetchEquipment(int equipmentId, Action<EquipmentData> onSuccess, Action<string> onError)
    {
        string url = $"{baseUrl}/api/equipment/{equipmentId}";

        using UnityWebRequest request = UnityWebRequest.Get(url);
        request.timeout = (int)timeoutSeconds;
        request.SetRequestHeader( "Content-Type", "application/json");

        yield return request.SendWebRequest(); // ��û ������

        // ��û ���н�
        if (request.result != UnityWebRequest.Result.Success)
        {
            onError?.Invoke($"��û ���� ({request.responseCode}): {request.error}");
            yield break;
        }

        // ����ö� json�� EquipmentResponse ��ƼƼ�� ��ȯ
        EquipmentResponse response;

        try
        {
            response = JsonUtility.FromJson<EquipmentResponse>(request.downloadHandler.text);
        }
        catch (Exception e)
        {
            onError?.Invoke($"JSON �Ľ� ����: {e.Message}");
            yield break;
        }

        if (response.success && response.data != null)
        {
            onSuccess?.Invoke(response.data);
            
        } else
        {
            onError?.Invoke(response.message ?? "�����͸� ã�� �� �����ϴ�.");
        }


    }
}
