using UnityEngine;

public class Teleport : MonoBehaviour
{
    [SerializeField] private Transform spawnPoint; // �̵� ��ġ
    [SerializeField] private Transform xrRig; // XR RIG


    public void OnButtonPressed()
    {
        StartCoroutine(FadeController.Instance.FadeAndTeleport(() =>
        {
            Debug.Log("[Maintenance] �ڷ���Ʈ ����!");
            xrRig.position = spawnPoint.position;
            xrRig.rotation = spawnPoint.rotation;
        }));
    }

}