using System;
using System.Data.Common;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// �������� ����Ʈ�� ���� ������ 1��
public class MaintenanceItemUI : MonoBehaviour
{
    [Header("�ؽ�Ʈ")]
    public TMP_Text equipmentNameText;
    public TMP_Text workTypeText;
    public TMP_Text scheduledAtText;

    [Header("���� ����")]
    public Image statusDot;

    [Header("Ŭ�� ��ư")]
    public Button arrowButton;

    private MaintenanceData _data;

    // ������ �����ϴ� �Լ� (������, Ŭ�� �̺�Ʈ)
    public void SetData(MaintenanceData data, Action<MaintenanceData> onClicked)
    {
        _data = data;

        // ����
        if (equipmentNameText != null)
            equipmentNameText.text = data.equipment?.name ?? "-";

        // �۾� Ÿ��
        if (workTypeText != null)
            workTypeText.text = data.work_type ?? "-";

        // ���� �ð�
        if (scheduledAtText != null)
            if (DateTime.TryParse(data.scheduled_at, out DateTime dt))
                scheduledAtText.text = dt.ToLocalTime().ToString("M�� d�� HH:mm");
            else
                scheduledAtText.text = data.scheduled_at;

        if (statusDot != null)
        {
            statusDot.color = data.status switch
            {
                "in_progress" => new Color(0.22f, 0.54f, 0.87f),
                "scheduled" => new Color(0.7f, 0.7f, 0.7f),
                "completed" => new Color(0.39f, 0.6f, 0.13f),
                "cancelled" => new Color(0.9f, 0.1f, 0.1f),
                _ => new Color(0.7f, 0.7f, 0.7f),
            };
        }

        if (arrowButton != null)
        {
            arrowButton.onClick.AddListener(() => onClicked?.Invoke(_data));
        }

        
    }
}
